package view;

import javax.swing.*;
import java.awt.*;
 public class JFCliente  extends JFrame {
     JPanel pnlPesquisar, pnlClientes, pnlPrincipal, pnlDadosClientes, pnlBotoesClientes;
     JLabel lblPesquisar;
     JTextField txtPesquisar;
     JButton btnPesquisar,  btnExcluir;
     JTable tblPesquisar;

     public JFCliente(){
         setTitle("Cadastro de Cliente");
         setBounds(300,90,900,600);


         pnlPrincipal = new JPanel(new GridLayout(2,1,10,10));
         pnlPrincipal.setBackground(Color.blue);


         pnlPesquisar = new JPanel();
         pnlPesquisar.setBounds(300,90,900,300);
         pnlPesquisar.setBackground(Color.yellow);
         lblPesquisar = new JLabel("Nome");
         txtPesquisar = new JTextField();
         txtPesquisar.setColumns(60);
         btnPesquisar = new JButton("Pesquisar");

         Object [][] dados = {
                 {1,"Pietro", "09/03/1994","M","Rua das oliveiras","4343434334"},
                 {2,"Pong","09/03/2004","M","Rua das maconhas","23232132323"},
                 {3,"thiago","08/03/2006","M","Rua da pedra","23532132323"},
                 {4,"vidaloka","10/04/2011","M","Rua da craca","211132132323"},
                 {5,"zezinho","11/05/2006","M","Rua das maconhas","25555632323"},
                 {6,"zadamanga","09/03/2006","M","Rua da manga","244442132323"}

         };

         String [] colunas = {"Id","Nome","Data Nascimento","Sexo","Endereço","Fone"};




         tblPesquisar = new JTable(dados, colunas);

         tblPesquisar.getColumnModel().getColumn(0).setPreferredWidth(20);
         tblPesquisar.getColumnModel().getColumn(0).setResizable(false);
         tblPesquisar.getColumnModel().getColumn(1).setPreferredWidth(250);
         tblPesquisar.getColumnModel().getColumn(1).setResizable(false);
         tblPesquisar.getColumnModel().getColumn(2).setPreferredWidth(250);
         tblPesquisar.getColumnModel().getColumn(2).setResizable(false);
         tblPesquisar.getColumnModel().getColumn(3).setPreferredWidth(20);
         tblPesquisar.getColumnModel().getColumn(3).setResizable(false);
         tblPesquisar.getColumnModel().getColumn(4).setPreferredWidth(250);
         tblPesquisar.getColumnModel().getColumn(4).setResizable(false);
         tblPesquisar.getColumnModel().getColumn(5).setPreferredWidth(80);
         tblPesquisar.getColumnModel().getColumn(5).setResizable(false);


         pnlClientes = new JPanel(new BorderLayout());
         pnlClientes.setBackground(Color.PINK);

         pnlDadosClientes = new JPanel();
         pnlDadosClientes.setSize(600,180);
         pnlDadosClientes.setBackground(Color.green);
         pnlBotoesClientes = new JPanel();
         pnlBotoesClientes.setSize(280,180);
         pnlBotoesClientes.setBackground(Color.BLACK);

         btnExcluir = new JButton("Excluiir");


         pnlPrincipal.add(pnlPesquisar);
         pnlPesquisar.add(lblPesquisar);
         pnlPesquisar.add(txtPesquisar);
         pnlPesquisar.add(btnPesquisar);
         pnlPesquisar.add(tblPesquisar);
         pnlClientes.add(pnlDadosClientes, BorderLayout.CENTER);
         pnlClientes.add(pnlBotoesClientes, BorderLayout.EAST);
         pnlBotoesClientes.add(btnExcluir);



         pnlPrincipal.add(pnlClientes);
         getContentPane().add(pnlPrincipal);


         setDefaultCloseOperation(EXIT_ON_CLOSE);
     }
}
