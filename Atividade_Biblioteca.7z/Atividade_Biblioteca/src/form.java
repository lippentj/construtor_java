import javax.swing.*;

public class form {

    private JTextField textField1;
    private JButton pesquisarButton;
    private JTable table2;
}
