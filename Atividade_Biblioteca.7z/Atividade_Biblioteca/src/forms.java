import javax.swing.*;

public class forms {


    private JCheckBox checkBox1;
}
